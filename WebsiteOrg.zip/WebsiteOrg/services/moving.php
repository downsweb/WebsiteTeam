<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Moving Services</title>
    <link rel="stylesheet" href="moving.css"></link>
    <script type="text/javascript" src="service.js"></script>
</head>
<body>
<header>
        <div class="logo">
         
            <img src="/WebsiteOrg/gallery/G.jpg" alt="Logo">
        </div>
        <div class="brand-name">
            GLEAMING UPKEEP
        </div>
        <div class="login-signup">
            <a href="/WebsiteOrg/login/login.html">Login</a>
            <a href="/WebsiteOrg/signup/SignUp.html">Signup</a>
        </div>
    </header>

    <nav class="navbar">
        <div class="left-links">
          <a href="/WebsiteOrg/Homepage.html" >Home</a>
          <a href="/WebsiteOrg/about/newabout.html">About</a>
          <a href="/WebsiteOrg/services/services.html">Services</a>
          <a href="/WebsiteOrg/contact/contact.html">Contact</a>
        </div>
        <div class="right-links">
          <a href="/WebsiteOrg/cost/costest.html">Cost Estimator</a>
        </div>
      </nav>

      <div id="page">
    <div id="pageposition">
        <a href="/WebsiteOrg/services/indoor.php" id="indoortab" style="text-decoration: none;">Indoor</a>
        <a href="/WebsiteOrg/services/outdoor.php" id="outdoortab" style="text-decoration: none;">Outdoor</a>
        <a href="/WebsiteOrg/services/vehicle.php" id="vehicletab"style="text-decoration: none;">Vehicle</a>
        <a href="/WebsiteOrg/services/moving.php" id="movingtab"style="text-decoration: underline #7B967A;">Moving</a>
    </div>
      <hr/>
      </div>

      <div id="content">
        <div id="image">
          <img src="/WebsiteOrg/services/moving.jpg" alt="moving" id="serviceimg">
        </div>
        <div id="text">
          <h1> Moving Maintenance </h1>
          <p>
            Introducing our range of Moving Maintenance Services! At Gleaming Upkeep, we understand that transitions in life often involve more than just cleaning. Our comprehensive Moving Services cater to both big and small moves, ensuring a seamless transition to your new space. Whether you're relocating your home or office, our dedicated team will handle every aspect with care. From packing and organizing to loading and unloading, we make moving stress-free. Trust us to handle your valuables as if they were our own, ensuring a smooth and efficient moving experience that aligns with our commitment to cleanliness and precision.
          </p>
  
          <table align="center">
            <tr>
              <td>
                <h3>Moving Services:</h3>
                  <ul>
                    <li>Packing/Unpacking</li>
                    <li>Furniture Assembly (Big or Small)</li>
                    <li>Temporary Storage</li>
                    <li>Secure Handling of Valuables</li>
                  </ul>
              </td>
              <td>
                <input type="button" id="bookIndoorBtn" value="Book" onclick=book()></input>  
              </td>
           </tr>
          </table>
  
          </div>
        </div>
    </div>
  
  
    <div id="bookingContent">
        <div id="indoorHeading">
            <h2>Book Moving Maintenance Service</h2>
            <div id="bookIndoor">
                <form action="/WebsiteOrg/services/moving.php" id="bookIndoorForm" method="post">
                    <input type="text" name="bookIndoorName" id="bookIndoorName" placeholder="Name *" required></input>
                    <br/>
                    <input type="email" name="bookIndoorEmail" id="bookIndoorEmail" placeholder="Email *" required></input>
                    <br/>
                    <input type="tel" name="bookIndoorPhone" id="bookIndoorPhone" placeholder="Phone *" required></input>
                    <br/>
                    <input type="date" title="Please choose a date for when you want the service done." name="bookIndoorDate" id="bookIndoorDate" placeholder="Date" min="<?php echo date('Y-m-d'); ?>"></input>
                    <br/>
                    <textarea name="bookIndoorNote" title="Enter the moving service you want done, and any other information you would like us to know." id="bookIndoorNote" cols="30" rows="10" maxlength="500" placeholder="Note"></textarea>
                    <br/>
                    <input type="submit" id="bookIndoorBtn" value="Book"></input>
                </form>
            </div>
        </div>
    </div>
    <p align="center">Enter the moving service you want done and any other information you would like us to know, in the Note field.</p>
    <br/>

    <?php
    //connecting to MySQL.
    $connectmysql = mysqli_connect('localhost', 'root', '', 'booking');
    
    //Check to see MySQL is connected. If not, error message displays.
    if (!$connectmysql) {
        die('Cannot connect to MySQL!' . mysqli_error());
    } else {
        if (isset($_POST['bookIndoorName'], $_POST['bookIndoorEmail'], $_POST['bookIndoorPhone'])) {
            $bookingName = $_POST['bookIndoorName'];
            $bookingEmail = $_POST['bookIndoorEmail'];
            $bookingPhone = $_POST['bookIndoorPhone'];
            $bookingDate = $_POST['bookIndoorDate'];
            $bookingNote = $_POST['bookIndoorNote'];
            $serviceName = "Moving";
    
            // Check to see if user leaves fields empty, receives appropriate message.
            if (empty($bookingName) || empty($bookingEmail) || empty($bookingPhone)) {
                echo "Name, Email, and Phone are required fields.";
            } else {
               //Declaring an insert variable which will be used to insert values to the table. ? is used as placeholders to bind user input later.
               $insert = "INSERT INTO bookings (booking_name, booking_email, booking_phone, booking_date, booking_note, service_name) 
               VALUES (?, ?, ?, ?, ?, ?)";
               $dataAdded = mysqli_prepare($connectmysql, $insert);
               //Inserting user input values into the bookings table
               mysqli_stmt_bind_param($dataAdded, "ssssss", $bookingName, $bookingEmail, $bookingPhone, $bookingDate, $bookingNote, $serviceName);

                if (mysqli_stmt_execute($dataAdded)) {
                    echo "Thank you " .$bookingName. ", your booking has been confirmed!";
                } else {
                    echo "Error adding data: " . mysqli_error($connectmysql);
                }
            }
        }
    }
    ?>




      <footer>
            <p>&copy; 2023 Sheridan College</p>
        </footer>
</body>
</html>