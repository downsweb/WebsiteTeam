<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Outdoor Services</title>
    <link rel="stylesheet" href="/WebsiteOrg/services/outdoor.css"></link>
    <script type="text/javascript" src="service.js"></script>
</head>
<body>
<header>
        <div class="logo">
         
            <img src="/WebsiteOrg/gallery/G.jpg" alt="Logo">
        </div>
        <div class="brand-name">
            GLEAMING UPKEEP
        </div>
        <div class="login-signup">
            <a href="/WebsiteOrg/login/login.html">Login</a>
            <a href="/WebsiteOrg/signup/SignUp.html">Signup</a>
        </div>
    </header>

    <nav class="navbar">
        <div class="left-links">
          <a href="/WebsiteOrg/Homepage.html" >Home</a>
          <a href="/WebsiteOrg/about/newabout.html">About</a>
          <a href="/WebsiteOrg/services/services.html">Services</a>
          <a href="/WebsiteOrg/contact/contact.html">Contact</a>
        </div>
        <div class="right-links">
          <a href="/WebsiteOrg/cost/costest.html">Cost Estimator</a>
        </div>
      </nav>

      <div id="page">
    <div id="pageposition">
        <a href="/WebsiteOrg/services/indoor.php" id="indoortab" style="text-decoration: none;">Indoor</a>
        <a href="/WebsiteOrg/services/outdoor.php" id="outdoortab" style="text-decoration: underline #7B967A;">Outdoor</a>
        <a href="/WebsiteOrg/services/vehicle.php" id="vehicletab"style="text-decoration: none;">Vehicle</a>
        <a href="/WebsiteOrg/services/moving.php" id="movingtab"style="text-decoration: none;">Moving</a>
    </div>
    <hr/>
    </div>

    
    <div id="content">
      <div id="image">
        <img src="/WebsiteOrg/services/outdoor.jpg" alt="outdoor cleaning" id="serviceimg">
      </div>
      <div id="text">
        <h1> Outdoor Maintenance </h1>
        <p>
          Introducing our range of Outdoor Maintenance Services! Gleaming Upkeep goes beyond interiors to provide a complete outdoor transformation. Our Outdoor Services encompass a wide range of tasks designed to enhance the curb appeal and functionality of your property. From expert gardening and lawn care that nurtures lush greenery, to gutter cleaning that prevents water damage, we've got your exterior maintenance covered. Our skilled professionals also excel in outdoor handiwork and painting, ensuring that your property's aesthetics match its immaculate cleanliness. Discover a harmonious blend of nature and cleanliness with Gleaming Upkeep's Outdoor Services.
        </p>

        <table align="center">
          <tr>
            <td>
              <h3>Outdoor Services:</h3>
                <ul>
                  <li>Gardening</li>
                  <li>Lawncare</li>
                  <li>Gutter Cleaning </li>
                  <li>Painting</li>
                  <li>Outdoor Handiwork</li>
                </ul>
            </td>
            <td>
              <input type="button" id="bookIndoorBtn" value="Book" onclick=book()></input>  
            </td>
         </tr>
        </table>

        </div>
      </div>
  </div>


  <div id="bookingContent">
      <div id="indoorHeading">
          <h2>Book Outdoor Maintenance Service</h2>
          <div id="bookIndoor">
              <form action="/WebsiteOrg/services/outdoor.php" id="bookIndoorForm" method="post">
                  <input type="text" name="bookIndoorName" id="bookIndoorName" placeholder="Name *" required></input>
                  <br/>
                  <input type="email" name="bookIndoorEmail" id="bookIndoorEmail" placeholder="Email *" required></input>
                  <br/>
                  <input type="tel" name="bookIndoorPhone" id="bookIndoorPhone" placeholder="Phone *" required></input>
                  <br/>
                  <input type="date" title="Please choose a date for when you want the service done." name="bookIndoorDate" id="bookIndoorDate" placeholder="Date" min="<?php echo date('Y-m-d'); ?>"></input>
                  <br/>
                  <textarea name="bookIndoorNote" title="Enter the outdoor service you want done, and any other information you would like us to know." id="bookIndoorNote" cols="30" rows="10" maxlength="500" placeholder="Note"></textarea>
                  <br/>
                  <input type="submit" id="bookIndoorBtn" value="Book"></input>
              </form>
          </div>
      </div>
  </div>
  <p align="center">Enter the outdoor service you want done and any other information you would like us to know, in the Note field.</p>
  <br/>

  <?php
    //connecting to MySQL.
    $connectmysql = mysqli_connect('localhost', 'root', '', 'booking');
    
    //Check to see MySQL is connected. If not, error message displays.
    if (!$connectmysql) {
        die('Cannot connect to MySQL!' . mysqli_error());
    } else {
        if (isset($_POST['bookIndoorName'], $_POST['bookIndoorEmail'], $_POST['bookIndoorPhone'])) {
            $bookingName = $_POST['bookIndoorName'];
            $bookingEmail = $_POST['bookIndoorEmail'];
            $bookingPhone = $_POST['bookIndoorPhone'];
            $bookingDate = $_POST['bookIndoorDate'];
            $bookingNote = $_POST['bookIndoorNote'];
            $serviceName = "Outdoor Maintenance";
    
            // Check to see if user leaves fields empty, receives appropriate message.
            if (empty($bookingName) || empty($bookingEmail) || empty($bookingPhone)) {
                echo "Name, Email, and Phone are required fields.";
            } else {
              //Declaring an insert variable which will be used to insert values to the table. ? is used as placeholders to bind user input later.
              $insert = "INSERT INTO bookings (booking_name, booking_email, booking_phone, booking_date, booking_note, service_name) 
              VALUES (?, ?, ?, ?, ?, ?)";
              $dataAdded = mysqli_prepare($connectmysql, $insert);
              //Inserting user input values into the bookings table
              mysqli_stmt_bind_param($dataAdded, "ssssss", $bookingName, $bookingEmail, $bookingPhone, $bookingDate, $bookingNote, $serviceName);

                if (mysqli_stmt_execute($dataAdded)) {
                    echo "Thank you " .$bookingName. ", your booking has been confirmed!";
                } else {
                    echo "Error adding data: " . mysqli_error($connectmysql);
                }
            }
        }
    }
    ?>

      <footer>
            <p>&copy; 2023 Sheridan College</p>
        </footer>
</body>
</html>