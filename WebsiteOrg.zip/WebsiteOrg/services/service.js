
var learnIndoor;
var learnOutdoor; 
var learnVehicle; 
var learnMoving; 

function indoor(){
    
    learnIndoor = window.open("/WebsiteOrg/services/indoor.php", "_blank");
    
}

function outdoor(){

    learnOutdoor = window.open("/WebsiteOrg/services/outdoor.php", "_blank");

}
function vehicle(){

    learnVehicle = window.open("/WebsiteOrg/services/vehicle.php", "_blank");

}
function moving(){

    learnMoving = window.open("/WebsiteOrg/services/moving.php", "_blank");

}

function book(){
    
    var bookBtn = document.getElementById("bookingContent");
    bookBtn.scrollIntoView();
}

