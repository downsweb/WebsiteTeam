<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Indoor Services</title>
    <link rel="stylesheet" href="/WebsiteOrg/services/booking.css"></link>
    <script type="text/javascript" src="/WebsiteOrg/services/service.js"></script>
</head>
<body>
<header>
        <div class="logo">
         
            <img src="/WebsiteOrg/gallery/G.jpg" alt="Logo">
        </div>
        <div class="brand-name">
            GLEAMING UPKEEP
        </div>
        <div class="login-signup">
            <a href="/WebsiteOrg/login/login.html">Login</a>
            <a href="/WebsiteOrg/signup/SignUp.html">Signup</a>
        </div>
    </header>

    <nav class="navbar">
        <div class="left-links">
          <a href="\WebsiteOrg\Homepage.html" >Home</a>
          <a href="\WebsiteOrg\about\newabout.html">About</a>
          <a href="/WebsiteOrg/services/services.html">Services</a>
          <a href="/WebsiteOrg/contact/contact.html">Contact</a>
        </div>
        <div class="right-links">
          <a href="/WebsiteOrg/cost/costest.html">Cost Estimator</a>
        </div>
      </nav>

      <div id="page">
    <div id="pageposition">
        <a href="/WebsiteOrg/services/indoor.php" id="indoortab" style="text-decoration: underline #7B967A;">Indoor</a>
        <a href="/WebsiteOrg/services/outdoor.php" id="outdoortab" style="text-decoration: none;">Outdoor</a>
        <a href="/WebsiteOrg/services/vehicle.php" id="vehicletab"style="text-decoration: none;">Vehicle</a>
        <a href="/WebsiteOrg/services/moving.php" id="movingtab"style="text-decoration: none;">Moving</a>
    </div>
    <hr/>
    </div>

    <div id="content">
        <div id="image">
          <img src="cleaningcarpet.jpg" alt="cleaningcarpet" id="serviceimg">
        </div>
        <div id="text">
          <h1> Indoor Maintenance </h1>
          <p>
            Introducing our range of Indoor Maintenance Services! At Gleaming Upkeep, we understand the importance of a well-organized and clean living space, and that's why we offer services in organizing, cleaning, laundry, and cooking. Let our skilled professionals take care of your household needs, ensuring your home remains in tip top shape. Book an indoor maintenance service today!
          </p>

          <table align="center">
            <tr>
              <td>
                <h3>Indoor Services:</h3>
                  <ul>
                    <li>Home Organizing</li>
                    <li>Cleaning/Deep Cleaning</li>
                    <li>Carpet Washing </li>
                    <li>Laundry</li>
                    <li>Cooking</li>
                    <li>Indoor Handiwork</li>
                  </ul>
              </td>
              <td>
                <input type="button" id="bookIndoorBtn" value="Book" onclick=book()></input>  
              </td>
           </tr>
           </table>
          </div>
        </div>
    </div>



    <div id="bookingContent">
        <div id="indoorHeading">
            <h2>Book Indoor Maintenance Service</h2>
            <div id="bookIndoor">
                <form action="/WebsiteOrg/services/indoor.php" id="bookIndoorForm" method="post">
                    <input type="text" name="bookIndoorName" id="bookIndoorName" placeholder="Name *" required></input>
                    <br/>
                    <input type="email" name="bookIndoorEmail" id="bookIndoorEmail" placeholder="Email *" required></input>
                    <br/>
                    <input type="tel" name="bookIndoorPhone" id="bookIndoorPhone" placeholder="Phone *" required></input>
                    <br/>
                    <input type="date" title="Please choose a date for when you want the service done." name="bookIndoorDate" id="bookIndoorDate" placeholder="Date" min="<?php echo date('Y-m-d'); ?>"></input>
                    <br/>
                    <textarea name="bookIndoorNote" title="Enter the indoor service you want done, and any other information you would like us to know." id="bookIndoorNote" cols="30" rows="10" maxlength="500" placeholder="Note"></textarea>
                    <br/>
                    <input type="submit" id="bookIndoorBtn" value="Book"></input>
                </form>
            </div>
        </div>
    </div>
    <p align="center">Enter the indoor service you want done and any other information you would like us to know, in the Note field.</p>
    <br/>
    <?php
    //connecting to MySQL.
    $connectmysql = mysqli_connect('localhost', 'root', '', 'booking');
    
    //Check to see MySQL is connected. If not, error message displays.
    if (!$connectmysql) {
        die('Cannot connect to MySQL!' . mysqli_error());
    } else {
        if (isset($_POST['bookIndoorName'], $_POST['bookIndoorEmail'], $_POST['bookIndoorPhone'])) {
            $bookingName = $_POST['bookIndoorName'];
            $bookingEmail = $_POST['bookIndoorEmail'];
            $bookingPhone = $_POST['bookIndoorPhone'];
            $bookingDate = $_POST['bookIndoorDate'];
            $bookingNote = $_POST['bookIndoorNote'];
            $serviceName = "Indoor Maintenance";
    
            // Check to see if user leaves fields empty, receives appropriate message.
            if (empty($bookingName) || empty($bookingEmail) || empty($bookingPhone)) {
                echo "Name, Email, and Phone are required fields.";
            } else {
                //Declaring an insert variable which will be used to insert values to the table. ? is used as placeholders to bind user input later.
                $insert = "INSERT INTO bookings (booking_name, booking_email, booking_phone, booking_date, booking_note, service_name) 
                           VALUES (?, ?, ?, ?, ?, ?)";
                $dataAdded = mysqli_prepare($connectmysql, $insert);
                //Inserting user input values into the bookings table
                mysqli_stmt_bind_param($dataAdded, "ssssss", $bookingName, $bookingEmail, $bookingPhone, $bookingDate, $bookingNote, $serviceName);
            
                if (mysqli_stmt_execute($dataAdded)) {
                    echo "Thank you " .$bookingName. ", your booking has been confirmed!";
                } else {
                    echo "Error adding data: " . mysqli_error($connectmysql);
                }
            }
        }
    }
    ?>

      <footer>
            <p>&copy; 2023 Sheridan College</p>
        </footer>
</body>
</html>