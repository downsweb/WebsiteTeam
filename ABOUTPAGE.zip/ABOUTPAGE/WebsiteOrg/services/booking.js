const name = document.getElementById("name").value;
const email = document.getElementById("email").value;
const phone = document.getElementById("phone").value;
const service = document.getElementById("service");

const bookedService = {}

function bookIndoor(){

}
function bookOutdoor(){

}
function bookVehicle(){

}
function bookMoving(){

}

