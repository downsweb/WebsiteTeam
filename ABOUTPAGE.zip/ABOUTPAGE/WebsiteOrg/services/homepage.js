
var images=['gallery/ba1.jpg','gallery/ba3.jpg', 'gallery/ba4.jpg'];
var size=images.length;
var img_num=0;
var intr; // allows you to work with the interval cmds

function slide(num)
{
    img_num=img_num+num;// adding or subtarcting one each time
    if(img_num==size) //next
    {
        img_num=0;
    }
    if (img_num<0) //prev
    {
        img_num=size-1;
    }
    document.getElementById("pic").src=images[img_num];
}

function auto()
{
    intr=setInterval("slide(1)",1000); // changes image every second intr referencing interval
}

function stop()
{
    clearInterval(intr);
    // adding inre as a variable allows you to clear it
}