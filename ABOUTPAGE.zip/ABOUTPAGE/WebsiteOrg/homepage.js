var images = ['gallery/ba1.jpg', 'gallery/ba3.jpg', 'gallery/ba4.jpg'];
var size = images.length;
var img_num = 0;
var intr; // allows you to work with the interval cmds

function slide(num) {
    img_num = img_num + num; // adding or subtracting one each time
    if (img_num == size) {
        img_num = 0; // loop back to the first image
    }
    if (img_num < 0) {
        img_num = size - 1; // go to the last image when clicking previous on the first image
    }
    document.getElementById("pic").src = images[img_num];
}

function auto() {
    intr = setInterval(function() {
        slide(1);
    }, 1000); // changes image every second intr referencing interval
}

function stop() {
    clearInterval(intr);
}
