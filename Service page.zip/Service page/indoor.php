<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Indoor Services</title>
    <link rel="stylesheet" href="booking.css"></link>
</head>
<body>
    <header>
        <img src="G.jpg" alt="Logo">
        <h1 id="heading">Gleaming Upkeep</h1>
    </header>

    <nav>
        <a href="http://localhost/Project%20combined/Homepage.html">Home</a>
        <a href="#">About</a>
        <a href="http://localhost/Project%20combined/services.html">Services</a>
        <a href="#">Contact</a>
        <a href="#">Login</a>
    </nav>
    <div id="page">
    <div id="pageposition">
        <a href="http://localhost/Project%20combined/indoor.php" id="indoortab" style="text-decoration: underline #7B967A;">Indoor</a>
        <a href="http://localhost/Project%20combined/outdoor.html" id="outdoortab" style="text-decoration: none;">Outdoor</a>
        <a href="http://localhost/Project%20combined/vehicle.html" id="vehicletab"style="text-decoration: none;">Vehicle</a>
        <a href="http://localhost/Project%20combined/moving.html" id="movingtab"style="text-decoration: none;">Moving</a>
    </div>
    <hr/>
    </div>
    <div id="content">
        <div id="image">
        <img src="maintenance.jpg" alt="maintenance" id="serviceimg">
        </div>
        <div id="text">
        <h1> Indoor Maintenance </h1>
        <p>
        Introducing our range of Indoor Maintenance Services! At Gleaming Upkeep, we understand the importance of a well-organized and clean living space, and that's why we offer services in organizing, cleaning, laundry, and cooking. Let our skilled professionals take care of your household needs, ensuring your home remains in tip top shape. Book an Indoor Maintenance Services today!
        </p>
        </div>
    </div>

    <div id="bookingContent">
        <div id="indoorHeading">
            <h2>Book Indoor Maintenance Service</h2>
        </div>
            <div id="bookIndoor">
                <form action="http://localhost/Project%20combined/indoor.php" id="bookIndoorForm" method="post">
                    <input type="text" name="bookIndoorName" id="bookIndoorName" placeholder="Name *" required></input>
                    <br/>
                    <input type="email" name="bookIndoorEmail" id="bookIndoorEmail" placeholder="Email *" required></input>
                    <br/>
                    <input type="tel" name="bookIndoorPhone" id="bookIndoorPhone" placeholder="Phone *" required></input>
                    <br/>
                    <input type="date" title="Please choose a date for when you want the service done." name="bookIndoorDate" id="bookIndoorDate" placeholder="Date"></input>
                    <br/>
                    <textarea name="bookIndoorNote" id="bookIndoorNote" cols="30" rows="10" maxlength="500" placeholder="Note (optional)"></textarea>
                    <br/>
                    <input type="submit" id="bookIndoorBtn" value="Book"></input>
                </form>
            </div>
        </div>
    </div>
    <?php
    //connecting to MySQL.
    $connectmysql = mysqli_connect('localhost', 'root', '', 'booking');
    
    //Check to see MySQL is connected. If not, error message displays.
    if (!$connectmysql) {
        die('Cannot connect to MySQL!' . mysqli_error());
    } else {
        if (isset($_POST['bookIndoorName'], $_POST['bookIndoorEmail'], $_POST['bookIndoorPhone'])) {
            $bookingName = $_POST['bookIndoorName'];
            $bookingEmail = $_POST['bookIndoorEmail'];
            $bookingPhone = $_POST['bookIndoorPhone'];
            $bookingDate = $_POST['bookIndoorDate'];
            $bookingNote = $_POST['bookIndoorNote'];
    
            // Check to see if user leaves fields empty, receives appropriate message.
            if (empty($bookingName) || empty($bookingEmail) || empty($bookingPhone)) {
                echo "Name, Email, and Phone are required fields.";
            } else {
                //Declaring an insert variable which will be used to insert values to the table. ? is used as placeholders to bound user input later.
                $insert = "INSERT INTO bookings (booking_name, booking_email, booking_phone, booking_date, booking_note) 
                           VALUES (?, ?, ?, ?, ?)";
                $dataAdded = mysqli_prepare($connectmysql, $insert);
                //Inserting user input values into the bookings table
                mysqli_stmt_bind_param($dataAdded, "sssss", $bookingName, $bookingEmail, $bookingPhone, $bookingDate, $bookingNote);
            
                if (mysqli_stmt_execute($dataAdded)) {
                    echo "Thank you " .$bookingName. ", your booking has been confirmed!";
                } else {
                    echo "Error adding data: " . mysqli_error($connectmysql);
                }
            }
        }
    }
    ?>

    <script type="text/javascript" src="booking.js"></script>
    
</body>
    <footer>
    <p>&copy; 2023 Sheridan College</p>
    </footer>
</html>
