<!DOCTYPE html>
<html>
    <head>
    
            <link href="https://fonts.googleapis.com/css2?family=Lunasima&display=swap" rel="stylesheet">
            <link rel="stylesheet" href="SignupStyle.css">
            
        
    </head>

<body>
    
    <Div class="LoginBox">

    <Div class="MainText"> Create Your Gleaming Upkeep Account</Div>
    
    <h1 class="Please">Please Select A Username and Password</h1>
    <?php 
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // create variable that hold connection to database information
    $conn = new mysqli("localhost", "root", "", "sign_up_in");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get the input values from the form
    $full_name = $_POST["full_name"];
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Perform any necessary validation on the input data

    // Insert the new user record into the database
    $sql = "INSERT INTO users (full_name, username, password) VALUES ('$full_name', '$username', '$password')";

    if ($conn->query($sql) === TRUE) {
        echo "Signup successful!";
        sleep(3);
        header("Location: landingpage.html");
    } 
    else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
    <form action="SignUp.php" method="POST" class="form">
        <div class="username">
            <input type="text" id="full_name" name="full_name" placeholder="Full Name" required>
        </div>
        <div class="username">
            <input type="text" id="username" name="username" placeholder="Username" required>
        </div>
        <div class="password">
            <input type="password" id="password" name="password" placeholder="Password" required>
        </div>
        <div class="submit">
            <input type="submit" value="Sign Up">
        </div>
    </form>

    </Div>
</body>
</html>