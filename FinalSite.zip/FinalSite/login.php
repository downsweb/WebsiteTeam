<!DOCTYPE html>
<html>
    <head>
    
            <link href="https://fonts.googleapis.com/css2?family=Lunasima&display=swap" rel="stylesheet">
            <link rel="stylesheet" href="LoginStyle.css">
            
        
    </head>

<body>
    <script src="LoginScript.js"></script>
    <Div class="LoginBox">
     <Div class="logo">
            <img src="images\logo.jpg">
     </Div> 
    <Div class="MainText">Gleaming Upkeep</Div>
    <Div class="SubText">Services</Div> 
    <?php 
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Connect to your database (e.g., MySQL)
    $conn = new mysqli("localhost", "root", "", "sign_up_in");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get the input values from the form
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Fetch the user record from the database
    $sql = "SELECT * FROM users WHERE username = '$username'";
    $result = $conn->query($sql);

    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();
        if ($password === $row["password"]) {
            echo "Login successful!";
            // Redirect to user dashboard or another page after successful login
            header("Location: landingpage.html");
        } else {
            echo "Incorrect password.";
        }
    } else {
        echo "User not found.";
    }

    $conn->close();
}
?>
    <form action="login.php" method="POST" class="form"> 
    <Div class="form">
        <Div class="username">
            <input type="text" name="username" placeholder="USERNAME">
        </Div>
        <Div class="password">
            <input type="password" name="password" placeholder="PASSWORD">
        </Div>
        <button class="LogButt">Login</button>
    </form>    
    </br>
    </br>    
         
    </br>

        <button class="LogButt" onclick="window.location.href = 'SignUp.php'">Sign Up</button>
    </Div>
    <p>Don't have an account? <a href="SignUp.php">Sign Up</a></p>

    </Div>
</body>
</html>

