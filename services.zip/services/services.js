
var learnIndoor;
var learnOutdoor; 
var learnVehicle; 
var learnMoving; 


function indoor(){
    
    learnIndoor = window.open("http://localhost/Project%20combined/indoor.php", "_blank");
    
}

function outdoor(){

    learnOutdoor = window.open("http://localhost/Project%20combined/outdoor.html", "_blank");

}
function vehicle(){

    learnVehicle = window.open("http://localhost/Project%20combined/vehicle.html", "_blank");

}
function moving(){

    learnMoving = window.open("http://localhost/Project%20combined/moving.html", "_blank");

}

