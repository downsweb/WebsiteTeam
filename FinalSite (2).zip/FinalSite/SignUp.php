<!DOCTYPE html>
<html>
    <head>
    
            <link href="https://fonts.googleapis.com/css2?family=Lunasima&display=swap" rel="stylesheet">
            <link rel="stylesheet" href="SignupStyle.css">
            
        
    </head>

<body>

    <Div class="LoginBox">

    <Div class="MainText"> Create Your Gleaming Upkeep Account</Div>
    
    <h1 class="Please">Please Select A Username and Password</h1>
    <?php 
    // if the the request methhod used to send data to the server is post execute the contents of the if statement
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // the variable conn will hold the new connection to database
    $conn = new mysqli("localhost", "root", "", "sign_up_in");
   // checks if the connection to the database has an error 
   //if there is an error the connection will be killed using die and display "connection failed"
    if ($conn->connect_error) {
        die("Connection failed");
    }

    //retrives values submitted using post method from the html form and saves them to the variables 
    //"full_name" ,"username" and "password" corresponds to the name attibute in the html form 
    $full_name = $_POST["full_name"];
    $username = $_POST["username"];
    $password = $_POST["password"];

// if the length of the string stored in the $password variable is less than 6 say it should be longer 
if (strlen($password) < 6) {
    echo "Password should be at least 6 characters long.";
    exit(); 
}

    // Inserts the values stores in the varibles in to the user table
    $sql = "INSERT INTO users (full_name, username, password) VALUES ('$full_name', '$username', '$password')";
    // the query stored in the $sql variable  is executed on the database stored in the $conn variable
    //if execution is successfull the query will return TRUE and "signup successfull" will be displayed 
    if ($conn->query($sql) === TRUE) {

        echo "Signup successful!";

       // header("Location: landingpage.html");
    }
    else {
        echo "Error: ";
    }

    $conn->close();
}
?>
    <form action="SignUp.php" method="POST" class="form">
        <div class="fname">
            <input type="text" id="full_name" name="full_name" placeholder="Full Name" required>
        </div>
        <div class="username">
            <input type="text" id="username" name="username" placeholder="Username" required>
        </div>
        <div class="password">
            <input type="password" id="password" name="password" placeholder="Password" required>
        </div>
        <div>
        <button class="SignButt">Create Account</button>    
        
        </div>
        <p>Already have an account? <a href="login.php">Login</a></p>
    </form>

    </Div>
</body>
</html>