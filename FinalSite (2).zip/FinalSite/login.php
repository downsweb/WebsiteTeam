<?php
// if the session varibale user has be assign a value go to to the home page 
session_start();
if (isset($_SESSION["user"])) {
    header("Location: landingpage.php");
}
?>
<!DOCTYPE html>
<html>
    <head>
    
            <link href="https://fonts.googleapis.com/css2?family=Lunasima&display=swap" rel="stylesheet">
            <link rel="stylesheet" href="LoginStyle.css">
            
        
    </head>

<body>
    <script src="LoginScript.js"></script>
    <Div class="LoginBox">
     <Div class="logo">
            <img src="images\logo.jpg">
     </Div> 
    <Div class="MainText">Gleaming Upkeep</Div>
    <Div class="SubText">Services</Div> 
    <?php 
    // if the the request methhod used to send data to the server is post execute the contents of the if statement
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // the variable conn will hold the new connection database 
    $conn = new mysqli("localhost", "root", "", "sign_up_in");
   // checks if the connection to the database has an error 
   //if there is an error the connection will be killed using die and display "connection failed"
    if ($conn->connect_error) {
        die("Connection failed");
    }

    // retrives values submitted using post method from the html form and saves them to the variables 
    //"username" and "password" corresponds to the name attibute in the html form 
    $username = $_POST["username"];
    $password = $_POST["password"];

    // creates and SQL query and stores it in $sql variable
    //the query will retrive all columns from the user table where the username column matches the value stored in $username variable
    // that query is then executed on the database stored in $conn and the results of the query are stored in the $results varible 
    $sql = "SELECT * FROM users WHERE username = '$username'";
    $result = $conn->query($sql);
    //if the query stored in the $result varible has exactly one row fetch the data stored in that row and store it is the $row variable
    //if not show user not found
    //if that password stored in that row matches whats stored in the $pasword varible(user input) move them to the homepage
    //if not say incorrect password
    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();
        if ($password === $row["password"]) {
            echo "Login successful!";
            $_SESSION["user"] = "yes";
            header("Location: landingpage.php");
        } else {
            echo "Incorrect password.";
        }
    } else {
        echo "User not found.";
    }

    $conn->close();
}
?>
    <form action="login.php" method="POST" class="form"> 
    <Div class="form">
        <Div class="username">
            <input type="text" name="username" placeholder="USERNAME">
        </Div>
        <Div class="password">
            <input type="password" name="password" placeholder="PASSWORD">
        </Div>
        <button class="LogButt">Login</button>
    </form>    
    </br>

    </Div>
    <p>Don't have an account? <a href="SignUp.php">Sign Up</a></p>

    </Div>
</body>
</html>

